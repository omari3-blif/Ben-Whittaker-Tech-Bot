const { default: makeWASocket, DisconnectReason, useMultiFileAuthState, fetchLatestBaileysVersion } = require('@whiskeysockets/baileys');
const fs = require('fs');
const P = require('pino');
const dotenv = require('dotenv');
dotenv.config();

const OWNER_NUMBER = process.env.OWNER_NUMBER || '255760317060';
const AUTO_TYPING = process.env.AUTO_TYPING === 'on';
const AUTO_REACT = process.env.AUTO_REACT === 'on';

async function startSock() {
    const { state, saveCreds } = await useMultiFileAuthState('auth_info_ben_whittaker');
    const sock = makeWASocket({
        version: (await fetchLatestBaileysVersion()).version,
        logger: P({ level: 'silent' }),
        printQRInTerminal: true,
        auth: state
    });

    sock.ev.on('creds.update', saveCreds);
    sock.ev.on('connection.update', ({ connection, lastDisconnect }) => {
        if (connection === 'close') {
            const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
            if (shouldReconnect) startSock();
        } else if (connection === 'open') {
            console.log('Bot connected');
        }
    });

    sock.ev.on('messages.upsert', async ({ messages }) => {
        const msg = messages[0];
        if (!msg.message) return;
        const from = msg.key.remoteJid;

        const text = msg.message.conversation || msg.message.extendedTextMessage?.text || '';
        const sender = msg.key.participant || msg.key.remoteJid;

        if (AUTO_TYPING) {
            await sock.sendPresenceUpdate('composing', from);
        }

        if (AUTO_REACT) {
            await sock.sendMessage(from, { react: { text: '✅', key: msg.key }});
        }

        if (text.toLowerCase() === 'ping') {
            await sock.sendMessage(from, { text: '🥊 Pong!' });
        }

        // Placeholder for 200+ commands
        if (text.toLowerCase() === 'ai') {
            await sock.sendMessage(from, { text: '🤖 AI Feature is active!' });
        }

        if (text.toLowerCase() === 'sticker') {
            await sock.sendMessage(from, { text: '🖼️ Sticker feature here!' });
        }

        if (text.toLowerCase() === 'music') {
            await sock.sendMessage(from, { text: '🎵 Music feature ready!' });
        }

        // Add more commands here as needed...
    });
}

startSock();
