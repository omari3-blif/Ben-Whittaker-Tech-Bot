# Ben Whittaker Tech - Node.js WhatsApp Bot

Simple bot starter using Node.js.
