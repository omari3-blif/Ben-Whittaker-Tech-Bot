
// index.js - WhatsApp Bot Main File
require('dotenv').config();
const { default: makeWASocket, useSingleFileAuthState } = require('@whiskeysockets/baileys');
const P = require('pino');
const fs = require('fs');

const { state, saveState } = useSingleFileAuthState('./auth_info.json');

async function startBot() {
    const sock = makeWASocket({
        logger: P({ level: 'silent' }),
        printQRInTerminal: true,
        auth: state
    });

    sock.ev.on('creds.update', saveState);

    sock.ev.on('messages.upsert', async ({ messages }) => {
        const m = messages[0];
        if (!m.message) return;
        const msg = m.message.conversation || m.message.extendedTextMessage?.text || "";
        const sender = m.key.remoteJid;

        if (msg.toLowerCase() === "ping") {
            await sock.sendMessage(sender, { text: "🏓 Pong!" });
        }

        if (msg.toLowerCase() === "ai") {
            await sock.sendMessage(sender, { text: "🤖 AI feature is under development..." });
        }
    });
}

startBot();
