const { default: makeWASocket, useSingleFileAuthState, fetchLatestBaileysVersion, makeInMemoryStore } = require("@whiskeysockets/baileys")
require('dotenv').config()
const P = require('pino')
const { Boom } = require('@hapi/boom')
const fs = require('fs')
const path = require('path')
const readline = require('readline')
const qrcode = require('qrcode-terminal')

// Load .env config
const BOT_NAME = process.env.BOT_NAME || "Ben Whittaker Tech"
const OWNER_NUMBER = process.env.OWNER_NUMBER || "255760317060"

const { state, saveState } = useSingleFileAuthState('./auth_info.json')

const startSock = async () => {
    const { version, isLatest } = await fetchLatestBaileysVersion()
    const sock = makeWASocket({
        version,
        logger: P({ level: 'silent' }),
        printQRInTerminal: true,
        auth: state
    })

    sock.ev.on('creds.update', saveState)

    sock.ev.on('connection.update', ({ connection, lastDisconnect, qr }) => {
        if (connection === 'open') {
            console.log(`${BOT_NAME} Connected!`)
        } else if (connection === 'close') {
            console.log('Connection closed. Reconnecting...')
            startSock()
        }
    })

    sock.ev.on('messages.upsert', async ({ messages }) => {
        const msg = messages[0]
        if (!msg.message) return

        const text = msg.message.conversation || msg.message.extendedTextMessage?.text || ""

        if (text.toLowerCase() === 'hi') {
            await sock.sendMessage(msg.key.remoteJid, { text: `Hello, this is ${BOT_NAME}!` })
        }

        if (text.toLowerCase() === 'menu') {
            await sock.sendMessage(msg.key.remoteJid, { text: 'Features: AI, Music, Tools, Fun, Utilities, etc...' })
        }
    })
}

startSock()
