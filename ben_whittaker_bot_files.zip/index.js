// index.js
console.log("Ben Whittaker Tech WhatsApp bot is starting...");
// Add your main bot code here
