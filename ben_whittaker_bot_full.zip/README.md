# BEN WHITTAKER TECH BOT

WhatsApp bot with 200+ features built using Node.js and Baileys.

## Usage

1. Install dependencies:
```bash
npm install
```

2. Create `.env` file and add your OpenAI key:
```
OPENAI_API_KEY=your_key
```

3. Start bot:
```bash
node index.js
```

Scan QR code to connect your WhatsApp.
